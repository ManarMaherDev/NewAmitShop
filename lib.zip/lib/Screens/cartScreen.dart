import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/Cubit/BlocStates.dart';
import 'package:untitled/Cubit/Cubit.dart';


class cartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => AppCubit()
        ..createDB()
        ..getDataFromDatabase(AppCubit.db),
      child: BlocConsumer<AppCubit, AppStates>(
        listener: (BuildContext context, AppStates state) {
          AppCubit()..createDB();
        },
        builder: (BuildContext context, AppStates state) {
          AppCubit cubit = AppCubit.get(context);
          cubit.createDB();
          var item = AppCubit.get(context).newItems;

          print('list 1 ' + item.length.toString());

          return Scaffold(
              body: Column(
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(10, 30, 0, 0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Cart",
                    style: TextStyle(
                      fontSize: 30,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Container(
                height: MediaQuery.of(context).size.height - 200,
                child: ListView.builder(
                  itemCount: item.length,
                  itemBuilder: (context, index) => Card(
                    child: ListTile(
                      leading: SizedBox(
                        height: 70.0,
                        width: 60.0,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(3.0),
                          child: Image.network(
                            item[index]['avatar'],
                            fit: BoxFit.fill,
                          ),
                        ),
                      ), //add here
                      title: Text(
                        item[index]['name'],
                        style: TextStyle(fontSize: 18),
                      ),
                      subtitle: Row(
                        children: [
                          Text(item[index]['price'].toString() + " EGP",
                              style: TextStyle(fontSize: 16)),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Container(
                              padding: EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.white),
                              child: Row(
                                children: [
                                  InkWell(
                                      onTap: () {
                                        if(item[index]['count'] != 1){
                                          cubit.updateData(count:  item[index]['count']-1, id:  item[index]['id']);
                                        }

                                      },
                                      child: Icon(
                                        Icons.remove,
                                        color: Colors.black,
                                        size: 20,
                                      )),
                                  Container(
                                    margin: EdgeInsets.symmetric(horizontal: 3),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 3, vertical: 2),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(3),
                                        color: Colors.white),
                                    child: Text(
                                      item[index]['count'].toString(),
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  InkWell(
                                      onTap: () {
                                        cubit.updateData(count:  item[index]['count']+1, id:  item[index]['id']);
                                      },
                                      child: Icon(
                                        Icons.add,
                                        color: Colors.black,
                                        size: 20,
                                      )),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),

                      onTap: () {},
                    ),
                  ),
                ),
              ),
              Divider(thickness: 0.1, color: Colors.black),
              Row(
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(20, 10, 0, 0),
                    child: Text(
                      "Total : ",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child: Text(
                      cubit.getTotalPrice(),
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(70, 5, 0, 0),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.all(8),
                        fixedSize: Size(100, 50),
                        primary: Colors.red,
                      ),
                      onPressed: () {},
                      child: Text("Check Out"),
                    ),
                  ),
                ],
              ),
            ],
          ));
        },
      ),
    );
  }
}
