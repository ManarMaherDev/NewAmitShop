import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:untitled/Cubit/BlocStates.dart';
import 'package:untitled/Cubit/Cubit.dart';
import 'package:untitled/Models/Products.dart';
import 'package:untitled/Network/remote/dio_helper.dart';

import 'ProductItem.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static List<Products> itemsProducts = [];
  static List<dynamic> ProductsJson = [];

  @override
  void initState() {
    super.initState();
    DioHelper.init();
    getProducts();
    //DataStorage.createDB();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BlocProvider(
        create: (BuildContext context) => AppCubit(),

        child: BlocConsumer<AppCubit , AppStates>(
          listener: (context, AppStates state) {  },
          builder: (context ,AppStates state) {
            AppCubit cubit = AppCubit.get(context);
            cubit.createDB();
            return Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.white,
              centerTitle: true,
              title: Text(
                "Home",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            body: GridView.builder(
              padding: const EdgeInsets.all(16.0),
              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 300,
                  childAspectRatio: 8.0 / 9.0,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10),
              itemCount: itemsProducts.length,
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ProductItemScreen(itemsProducts[index])),
                    );
                  },
                  child: Card(
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        AspectRatio(
                          aspectRatio: 15.0 / 8.0,
                          child: Image.network(
                            itemsProducts[index].avatar.toString(),
                            fit: BoxFit.fitHeight,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16.0, 12.0, 16.0, 8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(itemsProducts[index]
                                      .name
                                      .substring(0, 16)
                                      .toString() +
                                  " .."),
                              const SizedBox(height: 8.0),
                              Row(
                                children: [
                                  IconButton(
                                    iconSize: 10,
                                    padding:
                                        new EdgeInsets.fromLTRB(0, 3.0, 0, 0.0),
                                    icon: new Icon(
                                      Icons.add_box_rounded,
                                      size: 18.0,
                                      color: Colors.red,
                                    ),
                                    onPressed: () {
                                      cubit.insertToDatabase(itemsProducts[index].id, itemsProducts[index].name, itemsProducts[index].avatar, 1, itemsProducts[index].price);

                                    },
                                  ),
                                  Text(itemsProducts[index].price.toString() +
                                      " EGP"),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
          } ,
        ),
      ),
    );
  }

  void getProducts() async {
    DioHelper.getData("api/products").then((value) {
      itemsProducts.clear();
      ProductsJson.clear();
      ProductsJson = value.data['products'];
    //  print(ProductsJson.toString());

      //print(ProductsJson[4]['id']);

      setState(() {
        var NullText = '';
        //  print(ProductsJson[0]['id']);

        for (int i = 0; i < ProductsJson.length; i++) {

          itemsProducts.add(Products(
            ProductsJson[i]['id'],
            ProductsJson[i]['name'],
            ProductsJson[i]['title'],
            ProductsJson[i]['avatar'],
            ProductsJson[i]['category_id'],
            ProductsJson[i]['price'],
            ProductsJson[i]['description'].toString(),
          ));
        }
      });
    }).catchError((onError) {
      print(onError.toString());
    });
  }
}
